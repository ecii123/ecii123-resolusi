#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

struct data
{
    char nama[50];
    int umur;
    int pin;
    int noRek;
    int saldo;
    int statuspin;
} nasabah[100];

void header()
{
    printf("\n=================================================\n");
    printf("|              ===ATM BERASAMA===               |\n");
    printf("=================================================\n");
}

void pinBlok()
{
    printf(" Anda Telah 3x Salah Memasukan PIN\n");
    printf(" Akun Anda Telah di Blokir\n");
    sleep(2);
}

void bDaftar()
{
    system("clear");
    header();
    printf(" Nomor Nomor Rekening anda belum terdaftar\n");
    sleep(2);
}

int main()
{
    int Norek, penarikan, setor, pilihganti, z, pin1, pinBaru, menu, x = 0;
    char kembali;
    srand(time(NULL));

    do
    {
    awal:
        system("clear");
        header();
        printf(" 1. Daftar Nasabah\n");
        printf(" 2. Aktivasi\n");
        printf(" 3. Cek Data Nasabh\n");
        printf(" 4. Setor Tunai\n");
        printf(" 5. Cek Saldo\n");
        printf(" 6. Tarik Tunai\n");
        printf(" 7. Keluar\n");
        printf("=================================================\n");
        printf(" Masukan Pilihan : ");
        scanf("%d", &menu);

        switch (menu)
        {
        case 1:
            system("clear");
            header();
            printf("                Daftar Nasabah                   \n");
            printf("=================================================\n");
            printf(" Masukan Nama Anda  : ");
            scanf("%s", nasabah[x].nama);
            printf(" Masukan Umur Anda  : ");
            scanf("%d", &nasabah[x].umur);

            if (nasabah[x].umur < 17)
            {
                printf(" Maaf Umur Anda Belum Cukup\n");
            }
            else
            {
                printf(" Masukan PIN anda   : ");
                scanf("%d", &nasabah[x].pin);
                printf(" Masukan Saldo Awal : ");
                scanf("%d", &nasabah[x].saldo);
                sleep(2);
                system("clear");
                header();
                printf("|           Pendaftaran Berhasail               |\n");
                printf("=================================================\n");
                nasabah[x].noRek = rand();
                printf(" No Rekening Anda : %d\n", nasabah[x].noRek);
                printf(" Nama  : %s\n", nasabah[x].nama);
                printf(" Umur  : %d\n", nasabah[x].umur);
                printf(" PIN   : %d\n", nasabah[x].pin);
                printf(" Saldo : %d\n", nasabah[x].saldo);
                sleep(1);
            }
            x++;
            break;

        case 2:
            system("clear");
            header();
            printf(" Masukan No Rekening : ");
            scanf("%d", &Norek);
            printf("=================================================\n");

            for (int i = 0; i < 100; i++)
            {
                if (Norek == nasabah[i].noRek)
                {
                    z += 1;
                    printf(" PIN Baru : ");
                    scanf("%d", &pin1);
                    nasabah[i].pin = pin1;
                    printf(" Konfirmasi PIN Baru : ");
                    scanf("%d", &pinBaru);

                    if (pinBaru == nasabah[i].pin)
                    {
                        sleep(2);
                        printf(" PIN berhasil di peerbarui\n");
                        nasabah[i].statuspin = 0;
                    }
                }
            }

            if (z == 0)
            {
                bDaftar();
            }
            z = 0;
            break;

        case 3:
            system("clear");
            header();
            printf(" Masukan No Rekening : ");
            scanf("%d", &Norek);

            for (int j = 0; j < 100; j++)
            {
                if (Norek == nasabah[j].noRek)
                {
                    if (nasabah[j].statuspin == 3)
                    {
                        z += 1;
                        printf(" Rekening Anda Telah di Blokir\n");
                        break;
                    }
                    z += 1;

                    do
                    {
                        if (nasabah[j].statuspin > 0)
                        {
                            printf("=================================================\n");
                            printf(" Anda telah salah %dx memasukan PIN!\n", nasabah[j].statuspin);
                        }
                        printf("=================================================\n");
                        printf(" Masukan PIN : ");
                        scanf("%d", &pin1);

                        if (pin1 == nasabah[j].pin)
                        {
                            printf(" Nama : %s\n", nasabah[j].nama);
                            printf(" Umur : %d\n", nasabah[j].umur);
                            printf(" PIN  : %d\n", nasabah[j].pin);
                            sleep(2);
                            break;
                        }
                        else
                        {
                            system("clear");
                            header();
                            nasabah[j].statuspin++;
                        }
                    } while (nasabah[j].statuspin < 3);

                    if (nasabah[j].statuspin == 3)
                    {
                        pinBlok();
                        goto awal;
                    }
                }
            }

            if (z == 0)
            {
                bDaftar();
            }
            z = 0;
            break;

        case 4:
            system("clear");
            header();
            printf(" Masukan No Rekening : ");
            scanf("%d", &Norek);

            for (int k = 0; k < 100; k++)
            {
                if (Norek == nasabah[k].noRek)
                {
                    if (nasabah[k].statuspin == 3)
                    {
                        z += 1;
                        printf(" Rekening Anda Telah di Blokir\n");
                        break;
                    }
                    z += 1;

                    do
                    {
                        if (nasabah[k].statuspin > 0)
                        {
                            printf("=================================================\n");
                            printf(" Anda telah salah %dx memasukan PIN!\n", nasabah[k].statuspin);
                        }
                        printf("=================================================\n");
                        printf(" Masukan PIN : ");
                        scanf("%d", &pin1);

                        if (pin1 == nasabah[k].pin)
                        {
                            system("clear");
                            header();
                            printf(" Saldo awal            : %d\n", nasabah[k].saldo);
                            printf(" Masukan Nominal Setor : ");
                            scanf("%d", &setor);

                            if (setor % 50000 == 0)
                            {
                                nasabah[k].saldo += setor;
                                printf(" Setor Tunai Berhasil\n");
                                sleep(1);
                                system("clear");
                                header();
                                printf(" Total Saldo : %d\n", nasabah[k].saldo);
                            }
                            else
                            {
                                printf("\n Setor Tunai Gagal\n");
                                printf(" ATM hanya menerima uang Rp.50000 dan Rp.100000\n");
                            }
                            break;
                        }
                        else
                        {
                            system("clear");
                            header();
                            nasabah[k].statuspin++;
                        }
                    } while (nasabah[k].statuspin < 3);

                    if (nasabah[k].statuspin == 3)
                    {
                        pinBlok();
                        goto awal;
                    }
                }
            }

            if (z == 0)
            {
                bDaftar();
            }
            z = 0;
            break;

        case 5:
            system("clear");
            header();
            printf(" Masukan No Rekening : ");
            scanf("%d", &Norek);

            for (int l = 0; l < 100; l++)
            {
                if (nasabah[l].statuspin == 3)
                {
                    z += 1;
                    printf(" Rekening Anda Telah di Blokir\n");
                    break;
                }
                z += 1;

                if (Norek == nasabah[l].noRek)
                {
                    do
                    {
                        if (nasabah[l].statuspin > 0)
                        {
                            printf(" Anda telah salah %dx memasukan PIN!\n", nasabah[l].statuspin);
                        }
                        printf("=================================================\n");
                        printf(" Masukan PIN : ");
                        scanf("%d", &pin1);

                        if (pin1 == nasabah[l].pin)
                        {
                            printf(" Saldo Anda : %d\n", nasabah[l].saldo);
                            break;
                        }
                        else
                        {
                            system("clear");
                            header();
                            nasabah[l].statuspin++;
                        }
                    } while (nasabah[l].statuspin < 3);

                    if (nasabah[l].statuspin == 3)
                    {
                        pinBlok();
                        goto awal;
                    }
                }

                break;
            }

            if (z == 0)
            {
                bDaftar();
            }
            z = 0;
            break;

        case 6:
            system("clear");
            header();
            printf(" Masukan No Rekening : ");
            scanf("%d", &Norek);

            for (int m = 0; m < 100; m++)
            {
                if (Norek == nasabah[m].noRek)
                {
                    if (nasabah[m].statuspin == 3)
                    {
                        z += 1;
                        printf(" Rekening Anda Telah di Blokir\n");
                        break;
                    }
                    z += 1;

                    do
                    {
                        if (nasabah[m].statuspin > 0)
                        {
                            printf("=================================================\n");
                            printf(" Anda telah salah %dx memasukan PIN!\n", nasabah[m].statuspin);
                        }
                        printf("=================================================\n");
                        printf(" Masukan PIN : ");
                        scanf("%d", &pin1);

                        if (pin1 == nasabah[m].pin)
                        {
                            system("clear");
                            header();
                            printf(" Masukan Nominal Penarikan : ");
                            scanf("%d", &penarikan);

                            if (penarikan % 50000 != 0)
                            {
                                system("clear");
                                printf(" Transaksi Gagal\n");
                                printf(" Anda Hanya Bisa Melakukan Penarikan Rp.50000\n");
                            }
                            else
                            {
                                if (penarikan >= nasabah[m].saldo)
                                {
                                    system("clear");
                                    header();
                                    printf(" Transaksi Gagal!\n");
                                    printf(" Karena Saldo Anda kurang!\n");
                                    printf(" Sisa Saldo Anda: Rp.%d\n", nasabah[m].saldo);
                                }
                                else if (penarikan <= 0)
                                {
                                    printf(" mana ada orang tarik tunai nominal %d\n", penarikan);
                                }
                                else
                                {
                                    system("clear");
                                    header();
                                    nasabah[m].saldo -= penarikan;
                                    printf(" Transaksi Berhasil\n");
                                    printf(" Sisa Saldo Anda: Rp.%d\n", nasabah[m].saldo);
                                }
                            }
                            break;
                        }
                        else
                        {
                            system("clear");
                            header();
                            nasabah[m].statuspin++;
                        }
                    } while (nasabah[m].statuspin < 3);

                    if (nasabah[m].statuspin == 3)
                    {
                        pinBlok();
                        goto awal;
                    }
                }
            }

            if (z == 0)
            {
                bDaftar();
            }
            z = 0;
            break;

        case 7:
            system("clear");
            header();
            printf("      Terimakasih Sudah Menggunakan ATM ini\n");
            printf("=================================================\n");
            exit(0);
        }

        printf("=================================================\n");
        printf(" Kembali ke Menu?[y/t] ");
        scanf(" %c", &kembali);

          // Konsumsi karakter newline
    while (getchar() != '\n');


    } while (kembali == 'y' || kembali == 'Y');
}
