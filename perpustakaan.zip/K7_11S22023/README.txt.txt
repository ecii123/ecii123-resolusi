Sebelum memulai langkah-langkah sebuah fitur penggunaan, pastikan perangkat Anda sudah terinstal dengan aplikasi NetBeans (proses instalasinya dapat ditemukan pada Praktikum 7) dan juga sudah terpasang JDBC (instalasi MariaDB dan SQLYog disertakan pada Praktikum 9).

Tahap untuk penggunaan Aplikasi My Bookshelf 
1. Buka netbeans pada perangkat anda
2. Pada "file", pilih "Open Project"
3. Pilih file project Aplikasi My Bookshelf yang ingin dijalankan
4. Selanjutna, kita terlebih dahulu mengatur "Set Project Configuration", dngan memilih "Customize"
5. Pada Customize, kita ppilih yang mana yang akan kita jalankan. Untuk tampilan awal pada aplikasi, pilih " StartFrame" pada main class
6. Klik oke
7 Lalu bisa bisa merun aplikasinya dengan mengklik icon run.
8. Apabila sudah ditampilkan tammpilan dari aplikasi, kita sudah sdapat memakai semua fitur yang ada


## Cara untuk menginstal sebuah file mariadb 
1. Kita mengklik dua akali aplikasi mariadb dan klik nex dengan sampe muncul tombol finis
https://institutteknologidel-my.sharepoint.com/personal/abdullah_ubaid_del_ac_id/_layouts/15/onedrive.aspx?id=%2Fpersonal%2Fabdullah%5Fubaid%5Fdel%5Fac%5Fid%2FDocuments%2Fsoftware%2Dkuliah%2Fpbo%2D2023&ga=1
2. Selanjut nya kita membuka sebuah netbeans untuk memindahkan file tersebut kedalam mariadb kedalam projek ini
3. Selanjutnya kita klik kanan pada projek dan pilih kategori libraries sesuai file yang sudah dan tambahkan file mariadb sesuai lokasi yang sudah ditentukan

##Cara untuk menginstal sebuah file jdbc
. selanjutnyankita masuk keaplikasiSQLYog
adapun fungsi - fungsi nya ialah :
- 

CREATE DATABASE IF NOT EXISTS myBookShelfPBO;
Berikutnya kita bisa mengeksekusi 
USE myBookShelfPBO;
lalu mengeksekusi 
CREATE TABLE IF NOT EXISTS myBook (
    isbn INT NOT NULL PRIMARY KEY,
    judul VARCHAR(50) NOT NULL,
    penulis VARCHAR(50) NOT NULL,
    penerbit VARCHAR(50) NOT NULL,
    tahun INT NOT NULL,
    sekarang INT NOT NULL DEFAULT 0,
    total INT NOT NULL,
    STATUS TINYINT(1) NOT NULL DEFAULT 0, 
    rating INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

Ketika kita inginmemeriksa tabel yang sudah tersedia didalam database SELECT * FROM myBook